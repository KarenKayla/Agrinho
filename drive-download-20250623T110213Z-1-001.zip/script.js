const fatos = [
  "Mais de 20% da Amazônia já foi destruída.",
  "As florestas tropicais abrigam cerca de 70% da biodiversidade mundial.",
  "O desmatamento contribui com aproximadamente 11% das emissões globais de CO₂.",
  "Reflorestar pode ajudar a recuperar o solo e regular o clima local.",
  "O Brasil é um dos países com maior índice anual de desmatamento."
];

function mostrarFato() {
  const indice = Math.floor(Math.random() * fatos.length);
  const fatoElemento = document.getElementById('fatoCurioso');

  // Animação de saída suave
  fatoElemento.style.opacity = 0;

  setTimeout(() => {
    fatoElemento.textContent = fatos[indice];
    // Animação de entrada suave
    fatoElemento.style.opacity = 1;
  }, 300);
}
